using Microsoft.AspNetCore.SignalR;

namespace MVC_project.Hubs
{
    public class TripHub : Hub
    {
        // Optional: server methods could be added here if needed
    }
}
